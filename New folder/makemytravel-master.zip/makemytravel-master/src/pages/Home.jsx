import React from "react";
import Styles from "./_pages.module.css";
const Home = () => {
  return <section id={Styles.pagesBlock}>Home</section>;
};

export default Home;
